# Ghost X2 Project Guidelines

## Project Overview
Building a 100% automated multi-agent hub-and-spoke system for grey-hat digital/ticket arbitrage, negative-option funnels, and white-label agency automation. Managed via Telegram and a Web UI dashboard.

## Tech Stack
- Backend: Python (FastAPI, APScheduler, Playwright)
- Database: Supabase (PostgreSQL)
- Infrastructure: Docker, Oracle Cloud VPS, Cloudflare Workers
- Control: Telegram Bot API + Custom Web UI

## Strict Rules for Claude Code
1. **Incremental Building:** Build one specific file or module at a time. Do not attempt to scaffold the entire project in a single response.
2. **Clean Secrets:** Never hardcode API keys, Stripe secrets, or Telegram bot tokens. Always read them from environment variables (`.env`).
3. **Keep Context Light:** Refer to `multi_agent_engine_master_architecture.md` for specs when needed, but output concise, production-ready code blocks.
