"""One-off live-database audit during Module 1 bring-up. Deleted after use."""

from engine.config import get_config
from engine.db import Database

db = Database(get_config())

print("engine.* tables:", [r["tablename"] for r in db.read(
    "select tablename from pg_tables where schemaname='engine' order by 1")] or "NONE")

if db.scalar("select to_regclass('engine.schema_migrations')"):
    print("journal rows:", db.read(
        "select version, left(checksum,10) as ck from engine.schema_migrations order by version"))
else:
    print("journal: absent")

print("engine enums:", [r["typname"] for r in db.read(
    "select t.typname from pg_type t join pg_namespace n on n.oid=t.typnamespace "
    "where n.nspname='engine' and t.typtype='e' order by 1")] or "NONE")

print("engine funcs:", [r["proname"] for r in db.read(
    "select p.proname from pg_proc p join pg_namespace n on n.oid=p.pronamespace "
    "where n.nspname='engine' order by 1")] or "NONE")

print("settings table DDL present:", bool(
    db.scalar("select to_regclass('engine.settings')")))

# Connections from this same host/user that are not us: crashed probe processes
# can sit in 'idle in transaction' holding the advisory lock.
print("other backends (mine + crashed probes):", db.read(
    "select pid, state, usename, application_name, now()-backend_start as age, "
    "left(query,45) as last_q from pg_stat_activity "
    "where datname=current_database() and pid <> pg_backend_pid() "
    "order by backend_start"))

print("advisory locks:", db.read(
    "select pid, classid, objid, mode, granted from pg_locks where locktype='advisory'")
    or "NONE")

db.close()
print("--- clean exit ---")
