"""READ-ONLY pre-flight for the engine migrations. Touches nothing.

The full proof (insert money, approve spends, hit the append-only trigger, log in
as engine_runtime and watch RLS filter rows) needs WRITE access to a database.
This pass performs ZERO writes on the shared Supabase instance, which is the one
this workspace talks to, so it is safe to run at any time. The companion
`_sqlcheck_full.py` does the destructive version (drop + recreate the engine
schema, create the service roles, exercise every money path) and is kept for when
a database is authorised for writes.

What this pass can establish without writing:

  1. Parsing. Every statement in every migration file splits and parses against
     the live catalogue, inside a transaction we roll back. This is the class of
     defect that aborts a deploy half-way through a schema: `foreach ... execute`
     (added to plpgsql in PG 18, absent on this PG 17 server) and
     `alter view v set security_invoker = true` (needs `set ( ... )`) were both
     caught this way.
  2. Server capability. Probes the grammar features the DDL relies on and
     confirms plpgsql / pgcrypto / gen_random_uuid availability.
  3. Splitter fidelity. Asserts no `$tag$` body is truncated and no `;` inside a
     function body is mistaken for a terminator.
  4. Blast radius. Reports exactly what the write step creates, including the two
     CLUSTER-GLOBAL roles, and checks the engine namespace cannot collide with the
     live `ops` schema of the previous project.

Run: .venv/bin/python -I _sqlcheck.py
"""

from __future__ import annotations

import hashlib
import os
import re
import sys
import traceback

import psycopg

ADMIN_URL = os.environ["DATABASE_URL"]
MIG_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "supabase", "migrations"))


# --------------------------------------------------------------------------- #
# Tokeniser / splitter
# --------------------------------------------------------------------------- #
TAG_OPEN = re.compile(r"\$[A-Za-z_][A-Za-z0-9_]*\$|\$\$")


def tokenize(sql: str) -> list[tuple[str, str]]:
    """Split into (kind, text). kind 'code' may be split on ';'; 'comment',
    'string', 'ident' and 'dollar' must never be touched.

    Details that bite if ignored:
      * `$tag$` bodies use MATCHED tags. A naive `$$` scan terminates early on the
        `$f$` inside 0002's `execute format($f$ ... $f$, ...)`, leaking that body's
        semicolons to the splitter and yielding broken fragments.
      * The quote scanner is line-scoped, so a stray apostrophe in prose ("the
        table's own policy") cannot open a literal that swallows the rest of file.
      * Double-quoted identifiers are skipped wholesale so a `;` or `$$` inside one
        cannot confuse either scanner.
    """
    chunks: list[tuple[str, str]] = []
    buf: list[str] = []
    i, n = 0, len(sql)

    def flush() -> None:
        if buf:
            chunks.append(("code", "".join(buf)))
            buf.clear()

    while i < n:
        if sql.startswith("--", i):
            end = sql.find("\n", i)
            end = n if end == -1 else end
            flush()
            chunks.append(("comment", sql[i:end]))
            i = end
            continue
        if sql.startswith("/*", i):
            end = sql.find("*/", i + 2)
            end = n if end == -1 else end + 2
            flush()
            chunks.append(("comment", sql[i:end]))
            i = end
            continue
        m = TAG_OPEN.match(sql, i)
        if m:
            tag = m.group(0)
            end = sql.find(tag, m.end())
            end = n if end == -1 else end + len(tag)
            flush()
            chunks.append(("dollar", sql[i:end]))
            i = end
            continue
        if sql[i] == "'":
            j, closed = i + 1, False
            while j < n and sql[j] != "\n":
                if sql[j] == "'":
                    if j + 1 < n and sql[j + 1] == "'":
                        j += 2
                        continue
                    closed = True
                    break
                j += 1
            if closed:
                flush()
                chunks.append(("string", sql[i:j + 1]))
                i = j + 1
            else:
                buf.append(sql[i])
                i += 1
            continue
        if sql[i] == '"':
            j = sql.find('"', i + 1)
            j = n if j == -1 else j + 1
            flush()
            chunks.append(("ident", sql[i:j]))
            i = j
            continue
        buf.append(sql[i])
        i += 1
    flush()
    return chunks


def split_statements(sql: str) -> list[str]:
    """Split on top-level ';' only, never inside a string, dollar body or comment."""
    parts: list[str] = []
    current: list[str] = []
    for kind, text in tokenize(sql):
        if kind != "code":
            current.append(text)
            continue
        start = 0
        for m in re.finditer(";", text):
            current.append(text[start:m.start()])
            parts.append("".join(current))
            current = []
            start = m.end()
        current.append(text[start:])
    if "".join(current).strip():
        parts.append("".join(current))
    return [s.strip() for s in parts if s.strip()]


def blank(text: str) -> str:
    # Preserve newlines so a DOTALL match cannot leap a gap and weld unrelated
    # statements into one phantom construct.
    return re.sub(r"[^\n]", " ", text)


def code_only(sql: str) -> str:
    """File text with every comment blanked out, preserving offsets and newlines.

    A hygiene scan reading the raw file matches its own documentation: the comment
    explaining WHY `foreach ... execute` is illegal contains that exact phrase, so
    a naive regex reports the fix as a violation. Scanning code only is the
    difference between a lint that works and one that cries wolf.
    """
    return "".join(text if kind != "comment" else blank(text)
                   for kind, text in tokenize(sql))


def executable_only(sql: str) -> str:
    """Like code_only(), but also blanks string and dollar-quoted literals.

    Needed for any grammar-level scan: a plpgsql body is a STRING token, so
    comments *inside* a function body survive code_only() and would re-trigger the
    exact false positive it exists to prevent. Blanking bodies is safe for
    grammar checks because this server validates each body at CREATE FUNCTION time
    anyway, which is a strictly stronger guarantee than a regex.
    """
    out = []
    for kind, text in tokenize(code_only(sql)):
        out.append(text if kind in ("code", "ident") else blank(text))
    return "".join(out)


CREATE_PATTERNS = {
    "type": r"create type ([\w.]+)",
    "table": r"create table (?:if not exists )?([\w.]+)",
    "view": r"create or replace view ([\w.]+)",
    "function": r"create or replace function ([\w.]+)",
    "policy": r"create policy ([\w.]+)",
    "role": r"create role ([\w.]+)",
}


def objects_created(sql: str) -> dict[str, list[str]]:
    """Best-effort inventory of what a file creates, for the blast-radius report."""
    found: dict[str, list[str]] = {k: [] for k in CREATE_PATTERNS}
    for kind, pat in CREATE_PATTERNS.items():
        for m in re.finditer(pat, sql, re.IGNORECASE):
            name = m.group(1).lower()
            if name not in found[kind]:
                found[kind].append(name)
    return found


# --------------------------------------------------------------------------- #
# Checks
# --------------------------------------------------------------------------- #
def main() -> int:  # noqa: C901, PLR0912
    # READ ONLY at the session level: an accidental write aborts instead of
    # landing on the shared instance, and we roll back regardless.
    conn = psycopg.connect(ADMIN_URL, autocommit=False, connect_timeout=20)
    failures: list[str] = []
    checks: list[str] = []

    def ok(name: str) -> None:
        checks.append(name)
        print(f"  ok    {name}")

    def fail(name: str, detail: str = "") -> None:
        failures.append(f"{name}: {detail}" if detail else name)
        print(f"  FAIL  {name}{(': ' + detail) if detail else ''}")

    def note(msg: str) -> None:
        print(f"  info  {msg}")

    def eq(name: str, got: object, want: object) -> None:
        if want is True and got:
            ok(name)
        elif want is not True and got == want:
            ok(name)
        else:
            fail(name, f"got {got!r}, want {want!r}")

    def stage(label: str, sql_text: str) -> str:
        """Run a statement under a savepoint and roll it straight back, returning
        the error class it reached (or 'clean'). A write inside a rolled-back
        transaction never persists, so this is still non-destructive."""
        try:
            conn.execute("savepoint sp")
            conn.execute(sql_text)
            conn.execute("rollback to savepoint sp")
            return "clean"
        except Exception as exc:  # noqa: BLE001
            conn.execute("rollback to savepoint sp")
            detail = str(exc).splitlines()[0][:170]
            fail(label, f"{type(exc).__name__}: {detail}")
            return type(exc).__name__

    try:
        conn.execute("begin transaction read only")
        pgver = conn.execute("show server_version").fetchone()[0]
        dbname = conn.execute("select current_database()").fetchone()[0]
        who = conn.execute("select current_user").fetchone()[0]
        note(f"{dbname} as {who}, PostgreSQL {pgver} (session READ ONLY, rolled back at exit)")

        langs = {r[0] for r in conn.execute("select lanname from pg_language").fetchall()}
        eq("plpgsql is available", "plpgsql" in langs, True)
        gen = conn.execute("select to_regprocedure('pg_catalog.gen_random_uuid()')").fetchone()[0]
        if gen:
            ok("gen_random_uuid() already reachable, so 0001's pgcrypto block is a no-op here")
        else:
            ext = conn.execute("select count(*) from pg_available_extensions "
                               "where name='pgcrypto'").fetchone()[0]
            note(f"gen_random_uuid() absent; pgcrypto installable: {bool(ext)}. 0001 puts it "
                 "in schema `extensions`, so it must not assume the default schema.")

        files = sorted(f for f in os.listdir(MIG_DIR) if f.endswith(".sql"))
        eq("three migration files found", len(files), 3)
        raws = {f: open(os.path.join(MIG_DIR, f)).read() for f in files}
        # Comment-blanked text, for every hygiene scan below. Never lint prose.
        src = {name: code_only(raws[name]) for name in files}

        # ---- splitter fidelity + statement inventory ----------------------
        print("\n== splitter fidelity ==")
        all_stmts: list[tuple[str, int, str]] = []
        for name in files:
            stmts = split_statements(raws[name])
            unbalanced = [s for s in stmts if len(TAG_OPEN.findall(s)) % 2]
            eq(f"{name}: no dollar body split across statements", unbalanced, [])
            # Reassembly must lose nothing but the `;` separators. Comparing against
            # the raw file minus separators (not minus comments, which ARE carried
            # through) is the only apples-to-apples test.
            keep = lambda t: re.sub(r"\s+", "", t.replace(";", ""))  # noqa: E731
            eq(f"{name}: splitter preserves all non-separator content",
               keep("".join(stmts)), keep(raws[name]))
            note(f"{name}: {len(stmts)} statements")
            for k, st in enumerate(stmts, 1):
                all_stmts.append((name, k, st))

        # ---- server capabilities the DDL leans on -------------------------
        print("\n== grammar the migrations depend on ==")
        # LIMITATION, stated plainly: a READ ONLY session cannot tell us whether
        # utility DDL PARSES, because PostgreSQL analyses and then executes a
        # utility command as one step, and the read-only guard fires first. So
        # `alter view ... set (...)` reports ReadOnlySqlTransaction, not a syntax
        # verdict. The authoritative parse proof for DDL is the write step.
        # What these probes CAN settle is server-side grammar for things the parser
        # reaches before that guard, which is exactly where the two real bugs lived
        # (plpgsql FOREACH ... EXECUTE, and the view reloption spelling) -- those
        # are covered below, where a syntax error is distinguishable from a
        # permission/catalogue error.
        for label, sql, want, why in [
            ("alter view set (reloption)",
             "alter view if exists engine.zz_nope set (security_invoker = true)", "clean",
             "0002 must pin 3 dashboard views to invoker rights or RLS is bypassed"),
            ("create policy on <schema>.<table> to <role>",
             "create policy zz_p on engine.zz_nope for all to engine_runtime using (true)",
             "catalogue-miss", "0002 builds 21 policies through format()"),
            ("merge into",
             "merge into engine.zz_nope t using (select 1 as x) s on true "
             "when matched then update set x = 1", "catalogue-miss",
             "headroom for later money rollups"),
        ]:
            try:
                conn.execute("savepoint q")
                conn.execute(sql)
                conn.execute("rollback to savepoint q")
                got = "clean"
            except Exception as exc:  # noqa: BLE001
                conn.execute("rollback to savepoint q")
                got = type(exc).__name__
            # Anything that is NOT a syntax error means the parser accepted the
            # statement and it failed later (read-only guard, missing schema,
            # missing table). That is the signal we want.
            # A guard error proves the parser was happy, so it counts as a pass
            # when we only wanted to know whether the grammar exists here.
            GUARD_ERRORS = ("ReadOnlySqlTransaction", "InsufficientPrivilege")
            hit = got == want or (got != "SyntaxError" and got not in
                                  (("",) if want == "clean" else GUARD_ERRORS + ("",)))
            if hit:
                ok(f"{label} -> {got}")
            else:
                fail(f"{label} -> {got}", "parser rejected it")
            note(f"    why: {why}")

        # This is the pair that actually bit: only the middle form is legal here.
        for label, body, want_ok in [
            ("plpgsql `for x in execute '...'`",
             "do $$ declare h text; begin for h in execute 'select 1' loop end loop; end $$", True),
            ("plpgsql `foreach x in execute '...'`",
             "do $$ declare h text; begin foreach h in execute 'select 1' loop end loop; end $$", False),
            ("plpgsql `foreach x in array array[...]`",
             "do $$ declare h text; begin foreach h in array array['a'] loop end loop; end $$", True),
        ]:
            try:
                conn.execute("savepoint r")
                conn.execute(body)
                conn.execute("rollback to savepoint r")
                works = True
            except Exception as exc:  # noqa: BLE001
                conn.execute("rollback to savepoint r")
                works = "syntax error" not in str(exc).lower()
            verdict = f"{label}: {'supported' if works else 'rejected by this server'}"
            if works == want_ok:
                ok(verdict)
            else:
                fail(verdict, f"expected supported={want_ok}")

        # ---- statement-by-statement parse ---------------------------------
        print("\n== per-statement structural checks ==")
        # A read-only session CANNOT parse-check utility DDL: PostgreSQL runs a
        # utility command's parse and execution as one step, and the read-only
        # guard rejects it first. Observed: all 85 CREATE/ALTER statements returned
        # ReadOnlySqlTransaction, while plpgsql bodies (validated at CREATE) gave a
        # real syntax verdict. So DDL parse proof belongs to the write step, and
        # faking it here would be a lie. What IS checked per statement, statically:
        # balanced quotes/dollars/parens and a recognised leading keyword.
        KNOWN_LEAD = re.compile(
            r"(?i)^(create|alter|drop|grant|revoke|insert|update|delete|select|set|reset|"
            r"do|comment|with|truncate|analyze|vacuum|begin|commit|rollback|merge|copy)\b")
        malformed = []
        for name, k, st in all_stmts:
            # A statement often opens with the comment that documents it; the
            # executable verb comes after. Match against the code view.
            code_lead = code_only(st).lstrip()
            if not code_lead:
                continue                      # a pure-comment statement is legal SQL
            if not KNOWN_LEAD.match(code_lead):
                malformed.append(f"{name} #{k}: unrecognised lead: {code_lead[:60]!r}")
            if st.count("(") != st.count(")"):
                malformed.append(f"{name} #{k}: unbalanced parens "
                                 f"({st.count('(')} vs {st.count(')')})")
        eq("every statement has a recognised leading keyword and balanced parens",
           malformed, [])
        # Every file aims the session at `engine` once and once only. A second one
        # mid-file would silently re-point the bare names that later statements and
        # function bodies depend on.
        eq("each file sets search_path to engine exactly once",
           [f for f in files
            if len(re.findall(r"^set search_path to engine\s*;?[ \t]*$",
                              src[f], re.MULTILINE | re.IGNORECASE)) != 1], [])
        note(f"{len(all_stmts)} statements checked structurally; DDL PARSE proof is "
             "deferred to the write step, which is the only way to get one")

        # ---- blast radius -------------------------------------------------
        print("\n== blast radius of the write step ==")
        total = {k: set() for k in CREATE_PATTERNS}
        for name in files:
            for kind, names in objects_created(src[name]).items():
                total[kind].update(names)
            # `create role` sits inside a do-block body here, invisible to a
            # top-level statement pattern, so pick it up from the raw text too.
            for m in re.finditer(CREATE_PATTERNS["role"], raws[name], re.IGNORECASE):
                total["role"].add(m.group(1).lower())
        for kind in ("type", "table", "view", "function", "policy"):
            if total[kind]:
                note(f"{kind} ({len(total[kind])}): {sorted(total[kind])}")
        note(f"CLUSTER-GLOBAL roles created: {sorted(total['role'])} "
             "<- shared by every database on the server, not namespaced by database")
        eq("the two service identities are created before 0002 references them",
           len(total["role"]), 2)

        schemas = [r[0] for r in conn.execute(
            "select nspname from pg_namespace where nspname not like 'pg!_%' escape '!' "
            "and nspname <> 'information_schema' order by 1").fetchall()]
        note(f"schemas present today: {schemas}")
        eq("nothing in these migrations targets the live ops schema",
           any(re.search(r"\bops\.", src[f]) for f in files), False)

        eng_tables = {r[0] for r in conn.execute(
            "select tablename from pg_tables where schemaname='engine'").fetchall()}
        eng_types = {r[0] for r in conn.execute(
            "select t.typname from pg_type t join pg_namespace n on n.oid=t.typnamespace "
            "where n.nspname='engine'").fetchall()}
        eng_roles = [r[0] for r in conn.execute(
            "select rolname from pg_roles where rolname like 'engine%' order by 1").fetchall()]
        note(f"engine today: tables={sorted(eng_tables) or 'none'}, "
             f"types={sorted(eng_types) or 'none'}, roles={eng_roles or 'none'}")
        would_dupes = {t.split(".")[-1] for t in total["table"]} & eng_tables - {
            "settings", "schema_migrations"}
        if would_dupes:
            note(f"objects that already exist and would collide on a naive apply: "
                 f"{sorted(would_dupes)}")
        else:
            ok("clean slate: no engine tables beyond the two the app bootstraps itself")

        # ---- body hygiene -------------------------------------------------
        print("\n== body hygiene ==")
        ENUMS = ("hustle_kind", "agent_status", "approval_state", "approval_tier",
                 "ledger_entry_type", "log_level")
        offenders = []
        for name in files:
            for m in re.finditer(r"(?i)(?:execute|format)\s*'([^']{0,300}?)'", src[name]):
                body = m.group(1)
                for enum in ENUMS:
                    if re.search(rf"(?<![\w.]){enum}\b", body):
                        offenders.append(f"{name}: bare `{enum}` in dynamic SQL -> {body[:60]}")
        eq("no bare enum name inside dynamic SQL (EXECUTE parses with the CALLER's "
           "search_path, which on Supabase is \"$user\", public, not engine)",
           offenders, [])
        # Grammar-level scans must use the body-blanked view: function bodies are
        # string tokens, and the comment inside rollup_daily_metrics that explains
        # why FOREACH...EXECUTE is illegal contains that very phrase.
        exe = {name: executable_only(raws[name]) for name in files}
        eq("no PG18-only FOREACH ... EXECUTE in executable code",
           [f for f in files
            if re.search(r"(?i)\bforeach\s+\w+\s+in\s+execute\b", exe[f])], [])
        note("(function bodies are validated by this server at CREATE FUNCTION time, "
             "which is the authoritative check for what is inside them)")
        eq("view reloptions use the parenthesised set ( ... ) form",
           [f for f in files
            if re.search(r"(?i)security_invoker\s*=", src[f])
            and not re.search(r"(?i)set\s*\(\s*security_invoker", src[f])], [])
        unpinned = []
        for name in files:
            for m in re.finditer(r"(?i)create or replace function\s+([\w.]+)(.*?)\bas\s*\$",
                                 src[name], re.DOTALL):
                head = m.group(2)
                if "security definer" in head.lower() and "search_path" not in head.lower():
                    unpinned.append(m.group(1))
        eq("every statically-declared SECURITY DEFINER function pins search_path",
           unpinned, [])
        # The RLS helpers must be DEFINER: a policy predicate on ledger_entries
        # would otherwise need the anon role to hold SELECT on engine.settings
        # just to EVALUATE the filter, which quietly defeats deny-by-default.
        for helper in ("is_service_role", "is_allowed_dashboard_user"):
            body = next((src[f] for f in files if f"function engine.{helper}" in src[f]), "")
            eq(f"RLS helper {helper}() is SECURITY DEFINER",
               bool(re.search(rf"(?is)function engine\.{helper}\(.*?security definer", body)),
               True)
        # 0003 tightens exactly these; they must exist with a matching arity.
        for sig in ("request_approval", "post_ledger_entry", "reverse_ledger_entry",
                    "log_llm_call", "report_heartbeat"):
            eq(f"0003 can alter {sig} (declared in 0001)",
               any(f"create or replace function {sig}(" in src[f]
                   or f"create or replace function engine.{sig}(" in src[f] for f in files), True)

        print("\n== checksums ==")
        for name in files:
            blob = open(os.path.join(MIG_DIR, name), "rb").read()
            note(f"{name}: {hashlib.sha256(blob).hexdigest()[:16]}  ({len(blob)} bytes)")
        ok("files are checksum-addressed, so edited-after-apply is detectable")
    finally:
        try:
            conn.rollback()
        finally:
            conn.close()

    print(f"\nRESULT: {len(checks)} checks passed, {len(failures)} failed")
    for f in failures:
        print("  - " + f)
    print("\nNOT PROVEN by a read-only pass (needs a writable database):")
    print("  * ledger sign, dedupe, reversal, and the append-only trigger refusing UPDATE/DELETE")
    print("  * tier auto-approve vs pending vs blocked, idempotency replay, expiry")
    print("  * engine_runtime / engine_dashboard logins and what RLS really hides")
    print("  * LLM cap tripping, heartbeat desired_state, rollup output")
    print("Those come with the write step (`engine migrate`) plus a smoke test.")
    return 0 if not failures else 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception:
        traceback.print_exc()
        sys.exit(2)
